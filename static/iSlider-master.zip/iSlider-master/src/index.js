require('../build/iSlider.css');
// require("exports?iSlider!./export-iSlider");
var iSlider = require("../build/iSlider.js");
require('../build/iSlider.animate');
// require('../build/iSlider.plugin.dot');
// require('../build/iSlider.plugin.button');
// require('../build/iSlider.plugin.BIZone');
// require('../build/iSlider.plugin.zoompic');

module.exports = iSlider;